﻿using System;
using System.Collections.Concurrent;

namespace MQUtility
{
    public class MQPool : IMQPool
    {
        public ConcurrentDictionary<string, IMQ> DicMQPool { get; private set; } = null;

        public MQPool(string name)
        {
            DicMQPool = new ConcurrentDictionary<string, IMQ>();
            AddMQPool(name);
        }

        public MQPool AddObjectMQ(string name)
        {
            AddMQPool(name);
            return this;
        }

        public IMQ GetMQ(string name)
        {
            return DicMQPool[name];
        }

        public void RegisterRcv(string name, Action<object> action)
        {
            DicMQPool[name].RegisterReceive(action);
        }
        public void RegisterPeek(string name, Func<object, bool> func)
        {
            DicMQPool[name].RegisterPeek(func);
        }

        public void SendMsg(string name, object msg)
        {
            TryFlow(() =>
            {
                DicMQPool[name].SendMsg(msg);
            });

        }
        public T PeekMsg<T>(string name)
        {
            var obj = DicMQPool[name].PeekMsg();
            return (T)obj;
        }
        public long GetDataCont(string name)
        {
            var count = DicMQPool[name].CountData();
            return count;
        }
        public void RemoveFirstData(string name)
        {
            TryFlow(() =>
            {
                DicMQPool[name].RemoveFirstData();
            });
           
        }
        public void ClearData(string name)
        {
         
            TryFlow(() =>
            {
                DicMQPool[name].ClearData();
            });

        }
        public void RemoveQueue(string name)
        {

            TryFlow(() =>
            {
                IMQ msg;
                DicMQPool[name].DeleteQueue();
                DicMQPool.TryRemove(name, out msg);
            });
          
        }
        private void AddMQPool(string name)
        {
            if (!DicMQPool.ContainsKey(name))
                DicMQPool.TryAdd(name, new MQ(name));
        }

        protected virtual void TryFlow(Action action, bool @throw = false)
        {
            try
            {
                action?.Invoke();
            }
            catch (Exception ex)
            {
               // _log.Error("例外事件發生", $"ex.Message={ex.Message}");
               // _log.Error("例外事件發生", $"ex.StackTrace={ex.StackTrace}");
                if (@throw) throw ;
            }
           
        }
    }
}
