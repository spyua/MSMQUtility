﻿namespace TestDomain
{
    public static class SystemMQ
    {
        public const string SndApp = "SndApp";
        public const string RcvApp = "RcvApp";
        public const string FunApp = "FuncApp";
    }
}
